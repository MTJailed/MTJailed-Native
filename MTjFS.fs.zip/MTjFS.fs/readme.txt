Welcome to MTjFS.

MTjFS was developed to provide somehow the same capabilities as a writable rootfs will bring you.
Modifyihg system files may lead to unexpected results, like a denial of service for example.


The kernelcache, shsh blobs and a system dump are located in /var/mobile
You can always escape MTjFS to the real iOS filesystem using cd /
To go back to MTjFS just type cd $home
All files and folders in MTjFS are writeable

